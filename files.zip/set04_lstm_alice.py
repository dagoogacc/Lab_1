# SET 4: Context-Aware Next-Word Prediction Using LSTM (alice.txt)
import re
import numpy as np
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, Embedding, LSTM, Dense
from tensorflow.keras.utils import to_categorical

FILE_PATH = "alice.txt"      # change path if needed
MAX_LEN = 20                 # max sequence length (keeps memory low)
MAX_SENTENCES = 4000         # limit for speed/memory; set None for all

# 2. Load
with open(FILE_PATH, "r", encoding="utf-8", errors="ignore") as f:
    raw = f.read()
print("Characters:", len(raw))
print(raw[:300])

# 3. Normalize: lowercase, split into sentences, REMOVE punctuation (stated rule)
text = raw.lower()
sentences = re.split(r"[.!?]+", text)
sentences = [re.sub(r"[^a-z\s]", " ", s) for s in sentences]
sentences = [" ".join(s.split()) for s in sentences]
sentences = [s for s in sentences if len(s.split()) > 2]
if MAX_SENTENCES:
    sentences = sentences[:MAX_SENTENCES]

tokenizer = Tokenizer()
tokenizer.fit_on_texts(sentences)

# 4. Vocabulary
vocab_size = len(tokenizer.word_index) + 1
print("Vocabulary size:", vocab_size)
print("Sample:", sentences[5], "->", tokenizer.texts_to_sequences([sentences[5]])[0])

# 5. N-gram sequences
seqs = []
for s in sentences:
    tokens = tokenizer.texts_to_sequences([s])[0]
    for i in range(1, len(tokens)):
        seqs.append(tokens[max(0, i + 1 - MAX_LEN):i + 1])

# 6. Padding, predictors/targets
max_len = max(len(s) for s in seqs)
seqs = pad_sequences(seqs, maxlen=max_len, padding="pre")
X, y_idx = seqs[:, :-1], seqs[:, -1]

# 7. Categorical targets + shape check
y = to_categorical(y_idx, num_classes=vocab_size)
print("X shape:", X.shape, "| y shape:", y.shape)

# 8. Model
model = Sequential([
    Input(shape=(max_len - 1,)),
    Embedding(vocab_size, 100),
    LSTM(64),
    Dense(vocab_size, activation="softmax"),
])

# 9. Compile + train
model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])
model.summary()
history = model.fit(X, y, epochs=30, batch_size=128, verbose=1)
print("Final training loss:", history.history["loss"][-1])

# 10. Predict + generate
index_word = tokenizer.index_word

def predict_next(text):
    s = tokenizer.texts_to_sequences([text.lower()])[0]
    s = pad_sequences([s], maxlen=max_len - 1, padding="pre")
    return index_word.get(int(np.argmax(model.predict(s, verbose=0))), "")

def generate(seed, n=10):
    for _ in range(n):
        seed += " " + predict_next(seed)
    return seed

seed = "the queen was very"      # choose a phrase that is not a verbatim training example
print("Next word:", predict_next(seed))
print("Generated text:", generate(seed, 10))
