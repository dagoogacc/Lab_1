# SET 5: Character-Level Prediction Using SimpleRNN (sherlock.txt)
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, SimpleRNN, Dense

# 1. Seeds
np.random.seed(42); tf.random.set_seed(42)

FILE_PATH = "sherlock.txt"
MAX_CHARS = 100000     # use a slice so one-hot arrays fit in memory (None = all)
SEQ_LEN = 40
STEP = 3               # stride between sequences
EPOCHS = 20

# 2. Read
with open(FILE_PATH, "r", encoding="utf-8", errors="ignore") as f:
    text = f.read().lower()
if MAX_CHARS:
    text = text[:MAX_CHARS]
print(text[:300]); print("Total characters:", len(text))

# 3. Mappings
chars = sorted(set(text))
char_to_idx = {c: i for i, c in enumerate(chars)}
idx_to_char = {i: c for c, i in char_to_idx.items()}

# 4. Encode
encoded = np.array([char_to_idx[c] for c in text])
vocab_size = len(chars)
print("Vocabulary size:", vocab_size)

# 5. Input-target pairs
starts = range(0, len(encoded) - SEQ_LEN, STEP)

# 6. One-hot (built directly to save memory)
X = np.zeros((len(starts), SEQ_LEN, vocab_size), dtype=np.float32)
y = np.zeros((len(starts), vocab_size), dtype=np.float32)
for n, i in enumerate(starts):
    for t in range(SEQ_LEN):
        X[n, t, encoded[i + t]] = 1
    y[n, encoded[i + SEQ_LEN]] = 1
print("X:", X.shape, "y:", y.shape)

# 7-8. Model
model = Sequential([
    Input(shape=(SEQ_LEN, vocab_size)),
    SimpleRNN(64),
    Dense(vocab_size, activation="softmax"),
])
model.compile(optimizer="adam", loss="categorical_crossentropy")
model.summary()

# 9. Train + plot
history = model.fit(X, y, epochs=EPOCHS, batch_size=128, verbose=1)
plt.plot(history.history["loss"])
plt.xlabel("Epoch"); plt.ylabel("Loss"); plt.title("Training Loss"); plt.show()

# 10. Generate 100 characters
def sample(preds, temperature=0.5):
    preds = np.log(np.asarray(preds, dtype="float64") + 1e-9) / temperature
    p = np.exp(preds); p /= p.sum()
    return np.random.choice(len(p), p=p)

seed = text[:SEQ_LEN]
generated = seed
for _ in range(100):
    x = np.zeros((1, SEQ_LEN, vocab_size), dtype=np.float32)
    for t, ch in enumerate(generated[-SEQ_LEN:]):
        x[0, t, char_to_idx[ch]] = 1
    generated += idx_to_char[sample(model.predict(x, verbose=0)[0])]
print("Seed     :", repr(seed))
print("Generated:", repr(generated[SEQ_LEN:]))
