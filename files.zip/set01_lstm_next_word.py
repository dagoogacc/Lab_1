# SET 1: Next-Word Prediction Using LSTM
import numpy as np
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, Embedding, LSTM, Dense
from tensorflow.keras.utils import to_categorical

# 1. Corpus
corpus = ["hello how are you", "hello I am fine", "I am doing great"]

# 2. Tokenization
tokenizer = Tokenizer()
tokenizer.fit_on_texts(corpus)
vocab_size = len(tokenizer.word_index) + 1
print("Vocabulary:", tokenizer.word_index)
print("Vocabulary size:", vocab_size)

# 3. Sentences -> integer sequences, then n-gram sequences
input_sequences = []
for line in corpus:
    tokens = tokenizer.texts_to_sequences([line])[0]
    for i in range(1, len(tokens)):
        input_sequences.append(tokens[:i + 1])
print("N-gram sequences:", input_sequences)

# 4. Padding, predictors and labels
max_len = max(len(s) for s in input_sequences)
input_sequences = pad_sequences(input_sequences, maxlen=max_len, padding="pre")
X = input_sequences[:, :-1]
y = input_sequences[:, -1]
y = to_categorical(y, num_classes=vocab_size)
print("X shape:", X.shape, "y shape:", y.shape)

# 5. Model
model = Sequential([
    Input(shape=(max_len - 1,)),
    Embedding(vocab_size, 10),
    LSTM(64),
    Dense(vocab_size, activation="softmax"),
])
model.summary()

# 6. Compile and train
model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])
history = model.fit(X, y, epochs=200, verbose=0)
print("Final training loss:", history.history["loss"][-1])

# 7. Prediction
index_word = {i: w for w, i in tokenizer.word_index.items()}

def predict_next(text):
    seq = tokenizer.texts_to_sequences([text])[0]
    seq = pad_sequences([seq], maxlen=max_len - 1, padding="pre")
    return index_word.get(int(np.argmax(model.predict(seq, verbose=0))), "")

def generate(seed, n_words=3):
    for _ in range(n_words):
        seed += " " + predict_next(seed)
    return seed

print("Next word after 'hello how':", predict_next("hello how"))
print("Generated:", generate("hello", 3))
