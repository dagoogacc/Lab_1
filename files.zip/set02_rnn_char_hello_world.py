# SET 2: Character-Level Text Prediction Using Simple RNN
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, SimpleRNN, Dense
from tensorflow.keras.utils import to_categorical

# 1. Corpus
text = "hello world"
print("Text:", text)

# 2. Character mappings
chars = sorted(set(text))
char_to_idx = {c: i for i, c in enumerate(chars)}
idx_to_char = {i: c for c, i in char_to_idx.items()}
vocab_size = len(chars)
print("Chars:", chars, "| char_to_idx:", char_to_idx)

# 3. Text -> numbers
encoded = [char_to_idx[c] for c in text]

# 4. Sequences of length 3
seq_len = 3
X_idx, y_idx = [], []
for i in range(len(encoded) - seq_len):
    X_idx.append(encoded[i:i + seq_len])
    y_idx.append(encoded[i + seq_len])

# 5. One-hot encoding
X = to_categorical(X_idx, num_classes=vocab_size)   # (samples, 3, vocab)
y = to_categorical(y_idx, num_classes=vocab_size)
print("X:", X.shape, "y:", y.shape)

# 6. Model
model = Sequential([
    Input(shape=(seq_len, vocab_size)),
    SimpleRNN(32),
    Dense(vocab_size, activation="softmax"),
])
model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])
model.summary()

# 7. Train
history = model.fit(X, y, epochs=300, verbose=0)
print("Final training loss:", history.history["loss"][-1])

# 8. Predict next char
seed = "hel"
x = to_categorical([[char_to_idx[c] for c in seed]], num_classes=vocab_size)
pred = np.argmax(model.predict(x, verbose=0))
print(f"Seed '{seed}' -> predicted next character: '{idx_to_char[pred]}'")

# 9. Plot loss
plt.plot(history.history["loss"])
plt.xlabel("Epoch"); plt.ylabel("Loss"); plt.title("Training Loss vs Epochs")
plt.show()
