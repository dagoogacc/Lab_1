# SET 7: Character-Level Text Generation Using Simple RNN (Alice.txt)
import re
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, SimpleRNN, Dense

FILE_PATH = "Alice.txt"
SEQ_LEN = 40
STEP = 3
EPOCHS = 20

# 1. Load
with open(FILE_PATH, "r", encoding="utf-8", errors="ignore") as f:
    raw = f.read()
print(raw[:500])

# 2. Remove Gutenberg header/footer, normalise
start = re.search(r"\*\*\* ?START OF.*?\*\*\*", raw)
if start:
    raw = raw[start.end():]
end = raw.find("*** END OF")
if end != -1:
    raw = raw[:end]
text = re.sub(r"\s+", " ", raw.lower()).strip()
print("Cleaned length:", len(text))

# 3. Vocabulary
chars = sorted(set(text))
char_to_idx = {c: i for i, c in enumerate(chars)}
idx_to_char = {i: c for c, i in char_to_idx.items()}
vocab_size = len(chars)
print("Vocab size:", vocab_size)

# 4. Integer sequence
encoded = np.array([char_to_idx[c] for c in text])

# 5. Input sequences + next-char targets
X, y = [], []
for i in range(0, len(encoded) - SEQ_LEN, STEP):
    X.append(encoded[i:i + SEQ_LEN]); y.append(encoded[i + SEQ_LEN])
X, y = np.array(X), np.array(y)

# 6. Train/test split
idx = np.random.RandomState(42).permutation(len(X))
split = int(0.9 * len(X))
X_train, X_test = X[idx[:split]], X[idx[split:]]
y_train, y_test = y[idx[:split]], y[idx[split:]]
print("Train:", X_train.shape, "Test:", X_test.shape)

# 7. Model (Embedding -> SimpleRNN -> Dense)
model = Sequential([
    Embedding(vocab_size, 32),
    SimpleRNN(128),
    Dense(vocab_size, activation="softmax"),
])
model.build(input_shape=(None, SEQ_LEN))

# 8. Summary + trainable params
model.summary()
print("Trainable parameters:", sum(int(np.prod(w.shape)) for w in model.trainable_weights))

# 9. Compile + train
model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])
model.fit(X_train, y_train, epochs=EPOCHS, batch_size=128,
          validation_data=(X_test, y_test), verbose=1)

# 10. Generate
def sample(p, temp=0.6):
    p = np.log(p.astype("float64") + 1e-9) / temp
    p = np.exp(p); p /= p.sum()
    return np.random.choice(len(p), p=p)

seed = text[:SEQ_LEN]
generated = seed
for _ in range(300):
    x = np.array([[char_to_idx[c] for c in generated[-SEQ_LEN:]]])
    generated += idx_to_char[sample(model.predict(x, verbose=0)[0])]
print("Generated text:\n", generated)
