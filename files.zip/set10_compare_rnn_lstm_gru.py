# SET 10: Performance Comparison of SimpleRNN, LSTM and GRU (shakespeare.txt, char-level)
import re, time
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, SimpleRNN, LSTM, GRU, Dense

FILE_PATH = "shakespeare.txt"
MAX_CHARS = 200000
SEQ_LEN = 40
STEP = 3
EPOCHS = 10

# 1. Load
with open(FILE_PATH, "r", encoding="utf-8", errors="ignore") as f:
    raw = f.read()
print(raw[:400])

# 2. Clean + vocabulary
text = re.sub(r"[ \t]+", " ", raw.lower())[:MAX_CHARS]
chars = sorted(set(text))
char_to_idx = {c: i for i, c in enumerate(chars)}
idx_to_char = {i: c for c, i in char_to_idx.items()}
vocab_size = len(chars)
print("Vocab size:", vocab_size)

# 3. Integers
encoded = np.array([char_to_idx[c] for c in text])

# 4. Sequences + targets
X, y = [], []
for i in range(0, len(encoded) - SEQ_LEN, STEP):
    X.append(encoded[i:i + SEQ_LEN]); y.append(encoded[i + SEQ_LEN])
X, y = np.array(X), np.array(y)

# 5. Split
idx = np.random.RandomState(42).permutation(len(X))
split = int(0.9 * len(X))
X_train, X_test = X[idx[:split]], X[idx[split:]]
y_train, y_test = y[idx[:split]], y[idx[split:]]
print("Train:", X_train.shape, "Test:", X_test.shape)

# 6-8. Same configuration, different recurrent layer
def build(layer_cls):
    m = Sequential([
        Embedding(vocab_size, 32),
        layer_cls(128),
        Dense(vocab_size, activation="softmax"),
    ])
    m.build(input_shape=(None, SEQ_LEN))
    m.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    return m

models = {"SimpleRNN": build(SimpleRNN), "LSTM": build(LSTM), "GRU": build(GRU)}

# 9. Train all with the same settings
results, histories, trained = {}, {}, {}
for name, m in models.items():
    print(f"\n=== Training {name} ===")
    t0 = time.time()
    h = m.fit(X_train, y_train, epochs=EPOCHS, batch_size=128, verbose=1)
    results[name] = {"time": time.time() - t0, "train_loss": h.history["loss"][-1]}
    histories[name] = h.history["loss"]

# 10. Test performance + generation
def sample(p, temp=0.6):
    p = np.log(p.astype("float64") + 1e-9) / temp
    p = np.exp(p); p /= p.sum()
    return np.random.choice(len(p), p=p)

def generate(m, seed, n=150):
    out = seed
    for _ in range(n):
        x = np.array([[char_to_idx.get(c, 0) for c in out[-SEQ_LEN:]]])
        out += idx_to_char[sample(m.predict(x, verbose=0)[0])]
    return out

seed = text[:SEQ_LEN]
print("\n%-10s %10s %12s %10s %10s" % ("Model", "Time(s)", "TrainLoss", "TestLoss", "TestAcc"))
for name, m in models.items():
    tl, ta = m.evaluate(X_test, y_test, verbose=0)
    r = results[name]
    print("%-10s %10.1f %12.4f %10.4f %10.4f" % (name, r["time"], r["train_loss"], tl, ta))

for name, m in models.items():
    print(f"\n--- {name} generated text ---\n{generate(m, seed)}")

for name, l in histories.items():
    plt.plot(l, label=name)
plt.xlabel("Epoch"); plt.ylabel("Training loss"); plt.legend(); plt.title("RNN vs LSTM vs GRU")
plt.show()
