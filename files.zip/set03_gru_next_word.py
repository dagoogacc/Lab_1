# SET 3: Next-Word Prediction Using GRU
import numpy as np
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, Embedding, GRU, Dense
from tensorflow.keras.utils import to_categorical

# 1. Corpus
corpus = [
    "machine learning is a subset of artificial intelligence",
    "deep learning uses neural networks with many layers",
    "neural networks learn patterns from data",
    "machine learning models learn from data",
    "deep learning models need a lot of data",
    "recurrent neural networks process sequential data",
    "gru is a type of recurrent neural network",
]

# 2. Tokenization
tokenizer = Tokenizer()
tokenizer.fit_on_texts(corpus)
vocab_size = len(tokenizer.word_index) + 1
print("Vocabulary:", tokenizer.word_index)

# 3. Sequences and n-grams
seqs = []
for line in corpus:
    tokens = tokenizer.texts_to_sequences([line])[0]
    for i in range(1, len(tokens)):
        seqs.append(tokens[:i + 1])

# 4. Padding + labels
max_len = max(len(s) for s in seqs)
seqs = pad_sequences(seqs, maxlen=max_len, padding="pre")
X, y = seqs[:, :-1], seqs[:, -1]
y = to_categorical(y, num_classes=vocab_size)
print("X:", X.shape, "y:", y.shape)

# 5. Model
model = Sequential([
    Input(shape=(max_len - 1,)),
    Embedding(vocab_size, 16),
    GRU(64),
    Dense(vocab_size, activation="softmax"),
])
model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])
model.summary()

# 6. Train
history = model.fit(X, y, epochs=300, verbose=0)
print("Final training loss:", history.history["loss"][-1])

# 7. Predict / generate
index_word = {i: w for w, i in tokenizer.word_index.items()}

def predict_next(text):
    s = tokenizer.texts_to_sequences([text])[0]
    s = pad_sequences([s], maxlen=max_len - 1, padding="pre")
    return index_word.get(int(np.argmax(model.predict(s, verbose=0))), "")

def generate(seed, n=4):
    for _ in range(n):
        seed += " " + predict_next(seed)
    return seed

print("Next word:", predict_next("deep learning"))
print("Generated:", generate("machine learning", 4))
