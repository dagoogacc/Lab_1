# SET 6: Conversational Next-Word Generation Using GRU (Alice in Wonderland.txt)
import re, time
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, Embedding, GRU, Dense
from tensorflow.keras.utils import to_categorical

FILE_PATH = "Alice in Wonderland.txt"
MAX_LEN = 20
MAX_SENTENCES = 4000

# 2. Read
with open(FILE_PATH, "r", encoding="utf-8", errors="ignore") as f:
    raw = f.read()
print(raw[1000:1400]); print("Corpus length:", len(raw))

# 3. Lowercase + sentence segmentation (split on . ! ?)
text = raw.lower().replace("\n", " ")
sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", text)]
sentences = [re.sub(r"[^a-z\s']", "", s) for s in sentences]
sentences = [" ".join(s.split()) for s in sentences if len(s.split()) > 2]
sentences = sentences[:MAX_SENTENCES]

# 4. Tokenizer
tokenizer = Tokenizer()
tokenizer.fit_on_texts(sentences)
vocab_size = len(tokenizer.word_index) + 1
print("Sample word->index:", list(tokenizer.word_index.items())[:10])
print("Vocabulary size:", vocab_size)

# 5. Prefix-target sequences
seqs = []
for s in sentences:
    toks = tokenizer.texts_to_sequences([s])[0]
    for i in range(1, len(toks)):
        seqs.append(toks[max(0, i + 1 - MAX_LEN):i + 1])

# 6. Pad + targets
max_len = max(len(s) for s in seqs)
seqs = pad_sequences(seqs, maxlen=max_len, padding="pre")
X, y_idx = seqs[:, :-1], seqs[:, -1]
y = to_categorical(y_idx, num_classes=vocab_size)
print("X:", X.shape, "y:", y.shape)

# 7-8. Model
model = Sequential([
    Input(shape=(max_len - 1,)),
    Embedding(vocab_size, 100),
    GRU(96),
    Dense(vocab_size, activation="softmax"),
])
model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])
model.summary()
print("Total parameters:", model.count_params())

# 9. Train
start = time.time()
history = model.fit(X, y, epochs=30, batch_size=128, verbose=1)
duration = time.time() - start
print(f"Final training loss: {history.history['loss'][-1]:.4f}")
print(f"Training duration: {duration:.1f} s")
plt.plot(history.history["loss"]); plt.xlabel("Epoch"); plt.ylabel("Loss")
plt.title("GRU Training Loss"); plt.show()

# 10. Predict / generate
index_word = tokenizer.index_word

def predict_next(seed):
    s = tokenizer.texts_to_sequences([seed.lower()])[0]
    s = pad_sequences([s], maxlen=max_len - 1, padding="pre")
    return index_word.get(int(np.argmax(model.predict(s, verbose=0))), "")

def generate(seed, n=8):
    for _ in range(n):
        seed += " " + predict_next(seed)
    return seed

for seed in ["alice was beginning", "the king said"]:
    print(f"'{seed}' -> next word: {predict_next(seed)}")
print("Continuation:", generate("alice was beginning", 8))
