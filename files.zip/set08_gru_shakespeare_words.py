# SET 8: Next-Word Prediction Using GRU (shakespeare.txt)
import re
import numpy as np
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, Embedding, GRU, Dense

FILE_PATH = "shakespeare.txt"
MAX_LINES = 6000      # subset for speed/memory
MAX_LEN = 15

# 1. Load
with open(FILE_PATH, "r", encoding="utf-8", errors="ignore") as f:
    raw = f.read()
print(raw[:400])

# 2. Clean
lines = []
for l in raw.lower().split("\n"):
    l = re.sub(r"[^a-z'\s]", "", l)
    l = " ".join(l.split())
    if len(l.split()) > 2:
        lines.append(l)
lines = lines[:MAX_LINES]

# 3. Tokenize + vocabulary
tokenizer = Tokenizer()
tokenizer.fit_on_texts(lines)
vocab_size = len(tokenizer.word_index) + 1
print("Vocabulary size:", vocab_size)

# 4-5. Integer sequences -> n-gram inputs and next-word labels
seqs = []
for l in lines:
    toks = tokenizer.texts_to_sequences([l])[0]
    for i in range(1, len(toks)):
        seqs.append(toks[max(0, i + 1 - MAX_LEN):i + 1])

# 6. Pad + split
max_len = max(len(s) for s in seqs)
seqs = pad_sequences(seqs, maxlen=max_len, padding="pre")
X, y = seqs[:, :-1], seqs[:, -1]
idx = np.random.RandomState(42).permutation(len(X))
split = int(0.9 * len(X))
X_train, X_test = X[idx[:split]], X[idx[split:]]
y_train, y_test = y[idx[:split]], y[idx[split:]]
print("Train:", X_train.shape, "Test:", X_test.shape)

# 7. Model
model = Sequential([
    Input(shape=(max_len - 1,)),
    Embedding(vocab_size, 100),
    GRU(128),
    Dense(vocab_size, activation="softmax"),
])

# 8. Summary + trainable params
model.summary()
print("Trainable parameters:", sum(int(np.prod(w.shape)) for w in model.trainable_weights))

# 9. Compile + train (sparse labels -> no one-hot needed)
model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])
model.fit(X_train, y_train, epochs=15, batch_size=128,
          validation_data=(X_test, y_test), verbose=1)

# 10. Predict + evaluate
loss, acc = model.evaluate(X_test, y_test, verbose=0)
print(f"Test loss: {loss:.4f} | Test accuracy: {acc:.4f}")

index_word = tokenizer.index_word
def predict_next(sentence):
    s = tokenizer.texts_to_sequences([sentence.lower()])[0]
    s = pad_sequences([s], maxlen=max_len - 1, padding="pre")
    return index_word.get(int(np.argmax(model.predict(s, verbose=0))), "")

for s in ["to be or not to", "what light through yonder"]:
    print(f"'{s}' -> {predict_next(s)}")
