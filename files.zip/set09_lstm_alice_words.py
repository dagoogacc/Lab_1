# SET 9: Next-Word Prediction Using LSTM (Alice.txt)
import re
import numpy as np
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, Embedding, LSTM, Dense

FILE_PATH = "Alice.txt"
MAX_LEN = 20

# 1. Load
with open(FILE_PATH, "r", encoding="utf-8", errors="ignore") as f:
    raw = f.read()
print(raw[:400])

# 2. Remove Gutenberg header/footer
start = re.search(r"\*\*\* ?START OF.*?\*\*\*", raw)
if start:
    raw = raw[start.end():]
end = raw.find("*** END OF")
if end != -1:
    raw = raw[:end]
text = raw.lower().replace("\n", " ")

# 3. Tokenize
sentences = [re.sub(r"[^a-z\s']", "", x) for x in re.split(r"(?<=[.!?])\s+", text)]
sentences = [" ".join(x.split()) for x in sentences if len(x.split()) > 2]
tokenizer = Tokenizer()
tokenizer.fit_on_texts(sentences)
vocab_size = len(tokenizer.word_index) + 1
print("Vocabulary size:", vocab_size)

# 4-5. Sequences + labels
seqs = []
for x in sentences:
    toks = tokenizer.texts_to_sequences([x])[0]
    for i in range(1, len(toks)):
        seqs.append(toks[max(0, i + 1 - MAX_LEN):i + 1])

# 6. Pad + split
max_len = max(len(x) for x in seqs)
seqs = pad_sequences(seqs, maxlen=max_len, padding="pre")
X, y = seqs[:, :-1], seqs[:, -1]
idx = np.random.RandomState(42).permutation(len(X))
split = int(0.9 * len(X))
X_train, X_test = X[idx[:split]], X[idx[split:]]
y_train, y_test = y[idx[:split]], y[idx[split:]]
print("Train:", X_train.shape, "Test:", X_test.shape)

# 7. Model
model = Sequential([
    Input(shape=(max_len - 1,)),
    Embedding(vocab_size, 100),
    LSTM(128),
    Dense(vocab_size, activation="softmax"),
])

# 8. Summary + trainable params
model.summary()
print("Trainable parameters:", sum(int(np.prod(w.shape)) for w in model.trainable_weights))

# 9. Compile + train
model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])
model.fit(X_train, y_train, epochs=20, batch_size=128,
          validation_data=(X_test, y_test), verbose=1)

# 10. Predict + evaluate
loss, acc = model.evaluate(X_test, y_test, verbose=0)
print(f"Test loss: {loss:.4f} | Test accuracy: {acc:.4f}")

index_word = tokenizer.index_word
def predict_next(seed):
    q = tokenizer.texts_to_sequences([seed.lower()])[0]
    q = pad_sequences([q], maxlen=max_len - 1, padding="pre")
    return index_word.get(int(np.argmax(model.predict(q, verbose=0))), "")

print("Next word after 'alice was beginning to':", predict_next("alice was beginning to"))
